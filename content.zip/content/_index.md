
# Godbles Frequency

我站直了，我成了太阳和地球之间的导体。

这里是灵性觉醒者的主页面。
